# AstroLaabh — Gemstone Efficacy Meter

### Product Requirements Document (PRD)

| | |
|---|---|
| **Product** | Gemstone Efficacy Meter (web app) |
| **Owner** | AstroLaabh Product |
| **Version** | v1.0 (draft for build) |
| **Date** | June 24, 2026 |
| **Source inputs** | Efficacy Meter Design Brief; AstroLaabh Brand Direction (Final V1) |
| **Status** | Ready for design + engineering review |

---

## 1. Overview

The Gemstone Efficacy Meter is a 9-step interactive web tool that scores how astrologically effective a customer's current gemstone is. It asks 9 targeted questions and returns a percentage score (0–100%) with a plain-language breakdown of every factor dragging the score down, grouped under three pillars: **Stone Quality**, **Light & Luster**, and **Wearing Compliance**.

It is **not** a replacement for an astrologer's consultation. It is a trust-building, educational instrument that surfaces the exact gaps in a customer's current stone and, in doing so, makes the case for a higher-quality, properly-worn stone — and for AstroLaabh's services (certification, energising, consultation).

**One-line positioning:** *Find out how well your gemstone is actually working — in 9 questions.*

---

## 2. Goals & non-goals

### Goals
- Let any visitor self-assess their current stone in under 3 minutes, with no account required.
- Educate the customer on *why* stone quality matters, using imagery and plain language rather than jargon.
- Produce a credible, defensible score with a per-pillar breakdown that tells the customer which dimension is weakest.
- Generate qualified leads and a natural hand-off to AstroLaabh consultation / energising / certification services.
- Embody the AstroLaabh brand: warm, authoritative, sacred-but-accessible.

### Non-goals
- Not a gemstone e-commerce checkout (v1 links out / hands off, it does not sell).
- Not a horoscope, kundali, or planetary-period (dasha) calculator.
- Not a replacement for lab certification or astrologer consultation.
- No diagnosis of the customer's *planetary need* — the tool assesses the stone they already have, not whether they should wear it.

### Success metrics
- **Completion rate** of the 9-step flow (target ≥ 60% of starts).
- **Median time to complete** (target ≤ 3 min).
- **Lead conversion**: % of completions that submit contact details / book a consult.
- **Drop-off by step** (to find friction).
- **Score distribution** (sanity check that scores aren't clustered unrealistically high or low).

---

## 3. Target users

| Segment | Context | What they need from the tool |
|---|---|---|
| **Pre-purchase researcher** | Considering buying a gemstone, wary of being cheated | Education on what "good" looks like; confidence to buy well |
| **Post-purchase doubter** | Already wearing a stone (often from a local jeweller), unsure it's genuine/effective | An honest read on what they own and what's missing |
| **Gifted / inherited wearer** | Wears a stone they didn't choose, knows little about it | Low-pressure way to learn, without feeling judged |

**Primary device:** mobile web (brand deck shows a mobile-first app). Must also work well on desktop.

---

## 4. Design principles (from the brief)

1. **Every question should feel like a knowledgeable friend asking — not a form.** Tone is warm, authoritative, never clinical.
2. **Honest without harsh.** The goal of the result screen is clarity, not shame. "Don't know" is a score signal, never a failure.
3. **Show, don't tell.** Imagery does the educating — especially for transparency, luster, carat scale, and treatment, where words fail.
4. **Quality cannot be faked by compliance.** Scoring is weighted so that a treated, opaque stone worn perfectly still scores low (< 30%).

---

## 5. Brand & visual design system

Derived from the AstroLaabh Brand Direction deck. The aesthetic is **luxury Vedic / celestial**: olive-and-sage with champagne gold, elegant serif display type, and sacred-geometry (yantra / compass) motifs over warm cream surfaces.

### 5.1 Color palette

| Token | Name (from deck) | Hex (approx.) | Usage |
|---|---|---|---|
| `--color-bg` | Travertine / Warm cream | `#F4EEE4` | App background, cards |
| `--color-surface` | Sage mist | `#E7DDCF` | Secondary surfaces, option cards |
| `--color-primary` | Deep Olive | `#4F5638` | Primary text, headers, nav, buttons |
| `--color-primary-soft` | Sage | `#8A9070` | Borders, inactive states, secondary text |
| `--color-accent` | Champagne Gold | `#C9A84C` | Logo, progress, selected state, key CTAs, score ring |
| `--color-accent-deep` | Antique gold | `#B08A3E` | Gradients, hover on gold |
| `--color-sand` | Warm Sand | `#C8AC8C` | Illustrative accents, dividers |
| `--color-ink` | Near-black olive | `#2A2E20` | High-contrast body text |

> Exact hex values to be locked against the brand deck's master palette during design QA. The named palette (Sage, Deep Olive, Warm Sand, Travertine Beige, Champagne Gold) is authoritative.

### 5.2 Typography
- **Display / headings:** an elegant high-contrast serif (matching the "ASTRO LAABH" wordmark). Used for the wordmark, step titles, score number, verdict.
- **Body / UI:** a clean humanist sans-serif for questions, hints, option labels, and buttons.
- **Tone of casing:** generous letter-spacing on small uppercase labels (e.g. "STEP 1 OF 9", pillar names), matching the deck's refined spacing.

### 5.3 Motifs & texture
- Octagonal faceted-gem logo mark as the loading / brand anchor.
- Subtle yantra / compass-rose line geometry as section ornament and background watermark (low opacity, never competing with content).
- Soft, rounded cards; thin gold hairline borders on selected items; gentle shadows. Calm, premium, uncluttered — the spatial inspiration (arches, ornamental gold) translates to restrained ornament, not busy UI.

### 5.4 Imagery (CRITICAL — see brief)
Photography is core to the product, not decoration. Each step has prescribed reference/instructional imagery (detailed per step in §7). All photography should be consistent in lighting, scale, and white/clean backgrounds for reference shots; warm and aspirational for ritual/lifestyle shots. The **Step 4 transparency 4-panel** and **Step 5 luster 4-panel** are the single most important images in the product — customer self-reporting is unreliable without them.

---

## 6. Core user flow

```
Landing / intro
   → Step 1  Stone selection            (anchor — sets all downstream logic)
   → Step 2  Origin                     (25 pts)
   → Step 3  Treatment                  (20 pts)
   → Step 4  Light transmission         (20 pts)
   → Step 5  Luster                     (15 pts)
   → Step 6  Carat weight               (15 pts)
   → Step 7  Certification              (5 pts)
   → Step 8  Metal + finger             (8 + 5 pts) [options vary by Step 1]
   → Step 9  Energising                 (7 pts)
   → Result screen  (overall % + 3 pillar bars + gap breakdown + CTA)
```

**Navigation rules**
- Linear, one question per screen. Persistent progress indicator ("Step X of 9" + gold progress bar).
- **Back** allowed at any step; answers persist if the user navigates back/forward.
- Each step requires a selection before **Continue** is enabled (every answer, including "Don't know", carries a score — there is no skip).
- Step 1's selection drives the dynamic options and "correct answers" in Step 8 (metal + finger) and the planet/stone naming throughout.
- No login required to take the test or see the result. Contact capture is offered *after* the result, never as a gate.

---

## 7. Step-by-step specification

Each step lists: question, hint, options with points, and image direction. Points shown are the **raw maximum** for that factor.

### Step 1 — Stone selection *(anchor, 0 pts)*
**Question:** "Which stone are you wearing?"
**Options (single-select):** Yellow Sapphire (Pukhraj · Jupiter) · Blue Sapphire (Neelam · Saturn) · Ruby (Manik · Sun) · Emerald (Panna · Mercury)
**Logic:** Sets the active stone → derives correct metal, correct finger, and ruling planet used in Step 8 and in result copy.
**Image:** 4-panel, one loose stone each in natural light, clean white background, consistent lighting & scale. *Purpose: identification.*

### Step 2 — Origin *(25 pts — highest weight)*
**Question:** "Do you know the origin of your stone?"
**Hint:** "Origin determines the stone's natural planetary resonance. A Kashmir sapphire and an African sapphire are chemically similar but astrologically very different."
**Options → points:**

| Option | Sub-label | Points |
|---|---|---|
| Yes — premium origin | Ceylon / Burma / Kashmir / Colombia | 25 |
| Yes — secondary origin | African, Brazilian, or other | 13 |
| Don't know | Bought from a local jeweller | 5 |
| May be synthetic / glass | No certificate | 0 |

**Image:** Side-by-side premium vs secondary origin of the *selected* stone, showing visible saturation/clarity difference; optional world map with origin belts highlighted in gold. *Purpose: education.*

### Step 3 — Treatment *(20 pts)*
**Question:** "Has the stone been treated?"
**Hint:** "Heat treatment irreversibly alters the crystal structure. In Jyotish, this is considered energetically equivalent to destroying the stone's ability to conduct planetary light."
**Options → points:**

| Option | Sub-label | Points |
|---|---|---|
| Unheated / untreated | Confirmed by lab certificate | 20 |
| Heated or treated | Standard commercial treatment | 6 |
| Don't know | No certificate available | 4 |
| Fracture-filled / heavily oiled | Visible clarity enhancement | 0 |

**Image:** Split untreated vs heated of the selected stone under magnification (silk inclusions vs healed fractures/flux); close-up of fracture-filling in emerald. *Purpose: recognition.*

### Step 4 — Light transmission *(20 pts)*
**Question:** "How does light behave in your stone?"
**Hint:** "Hold your stone up to a light source. A Jyotish-grade stone must be able to receive, travel through, and transmit planetary light. Opacity = blockage. Cloudiness = obstruction."
**Options → points:**

| Option | Sub-label | Points |
|---|---|---|
| Fully transparent | Light passes clean through — no cloudiness | 20 |
| Mostly transparent | Minor inclusions but light flows well | 14 |
| Cloudy or milky | Light diffuses — hard to see through | 6 |
| Opaque | No light passes through at all | 0 |

**Image (most visual support of any step):** 4-panel backlit sequence of the *same* stone at clear / slight haze / cloudy / opaque, shot exactly as the customer would at home; plus an instructional shot of a hand holding a stone to a window or phone torch. *Purpose: instruction + calibration. These are the most important images in the tool.*

### Step 5 — Luster *(15 pts)*
**Question:** "How is the luster of your stone?"
**Hint:** "Luster is the stone's surface ability to reflect light. A stone without luster cannot radiate the planet's energy outward. Vedic texts describe a dull stone as energetically inert."
**Options → points:**

| Option | Sub-label | Points |
|---|---|---|
| Bright and vivid | Strong reflective surface, catches light easily | 15 |
| Moderate sheen | Some shine but not brilliant | 9 |
| Dull or waxy | Flat surface, very little reflection | 3 |
| Scratched or damaged surface | Polish broken — light scatters unevenly | 0 |

**Image:** 4-panel luster reference (high vitreous / moderate / dull-matte / scratched) at a consistent angle; close-up of scratched vs well-polished surface. *Purpose: calibration.*

### Step 6 — Carat weight *(15 pts)*
**Question:** "What is the carat weight of your stone?"
**Options → points:**

| Option | Sub-label | Points |
|---|---|---|
| Under 2 carats | Below minimum threshold | 0 |
| 2–4 carats | Acceptable range | 8 |
| 4–6 carats | Strong efficacy range | 12 |
| 6+ carats | Optimal | 15 |

**Image:** Visual weight comparison — 4 stones of the selected type at 1.5ct / 3ct / 5ct / 7ct on the same background with a ruler or familiar object for scale. *Purpose: scale visualisation.*

### Step 7 — Certification *(5 pts)*
**Question:** "Does the stone have a lab certificate?"
**Tone:** non-threatening, not accusatory.
**Options → points:**

| Option | Sub-label | Points |
|---|---|---|
| Yes — international lab | GIA, GRS, Gübelin, SSEF | 5 |
| Yes — Indian lab | IGI India, GII, IGL, GTL | 3 |
| No certificate | Uncertified stone | 0 |

**Image:** Example GRS/GIA origin report with specific details masked, key fields (origin, treatment, weight) highlighted. *Purpose: education — distinguish a real certificate from a shop receipt/appraisal.*

### Step 8 — Metal & finger *(metal 8 pts, finger 5 pts — DYNAMIC)*
Two wearing-compliance factors on one screen. **Options change based on Step 1.** The developer must implement this conditional logic.

**Correct answers by stone:**

| Stone | Correct metal (8 pts) | Correct finger (5 pts) |
|---|---|---|
| Yellow Sapphire | Gold | Index |
| Blue Sapphire | Silver or Panchdhatu | Middle |
| Ruby | Gold | Ring |
| Emerald | Gold or Silver | Little |

**Scoring:** full metal points if the worn metal matches the correct metal for the selected stone, else 0 (partial credit may be defined for "Don't know" — see §8.3). Full finger points if the worn finger matches, else 0.
**Image:** Single hand image wearing the four stones on their correct fingers simultaneously (Yellow Sapphire–index, Blue Sapphire–middle, Ruby–ring, Emerald–little), warm skin tone, natural light; plus a metal-swatch comparison (gold / silver / panchdhatu) labelled. *Purpose: identification — remove ambiguity about finger names and metal type.*

### Step 9 — Energising *(7 pts)*
**Question:** "Was it energised before wearing?"
**Tone:** no judgment for not knowing the ritual.
**Options → points:**

| Option | Sub-label | Points |
|---|---|---|
| Yes — proper ritual | Correct mantra, day, and Panchang | 7 |
| Yes — basic washing only | Water or milk rinse, no mantra | 3 |
| No — worn directly | No energising done | 0 |
| Don't know | Gifted or inherited stone | 1 |

**Image:** Aspirational ritual setup — copper thali with stone, diyas, fresh flowers, raw milk, warm candlelit. No specific deity imagery (stay universally relevant). *Purpose: aspiration — seeds AstroLaabh's energising service.*

> **Note on option point values:** The brief fixes each factor's *maximum* points and the Vedic rationale (§8). Intermediate option values above (e.g., "secondary origin = 13") are a recommended interpolation and are the one place this PRD adds detail beyond the brief. They are surfaced explicitly so product/astrology can sign them off before build. The maximums and the worst-case constraint ("treated + opaque + perfect compliance < 30%") are non-negotiable.

---

## 8. Scoring model

### 8.1 Pillars and weights (from the brief)

**Pillar 1 — Stone Quality (65 pts)**

| Factor | Max | Rationale |
|---|---|---|
| Origin | 25 | Geological/chemical origin conditions determine planetary alignment; an origin's inclusion fingerprint is unreplicable. |
| Treatment status | 20 | Heat irreversibly alters the crystal lattice; Ratna Shastra holds a treated stone cannot transmit planetary energy. |
| Carat weight | 15 | Mass determines the volume of planetary energy held; under 2ct lacks sufficient mass for measurable influence. |
| Lab certification | 5 | Doesn't make a stone more powerful — it verifies every other claim is true. |

**Pillar 2 — Light & Luster (35 pts)**

| Factor | Max | Rationale |
|---|---|---|
| Light transmission | 20 | Planetary energy operates through light; opacity is an absolute disqualifier in Jyotish. |
| Surface luster | 15 | Luster is outward radiation of energy; a dull stone is *mruta* (dead). |

**Pillar 3 — Wearing Compliance (20 pts)**

| Factor | Max | Rationale |
|---|---|---|
| Metal setting | 8 | Each planet maps to a metal; the wrong metal breaks the energetic circuit. |
| Energising ritual | 7 | An unenergised stone is latent, not active. Correctable at any time. |
| Finger worn on | 5 | Wrong finger misdirects rather than nullifies — hence the lower weight. |

### 8.2 Normalization
Raw maximum = 65 + 35 + 20 = **120 points**. The customer-facing **efficacy score is a percentage**:

```
efficacy_percent = round( (stone_quality_raw + light_luster_raw + compliance_raw) / 120 * 100 )
```

Each pillar bar on the result screen shows that pillar's own percentage:
```
pillar_percent = round( pillar_raw / pillar_max * 100 )   // max = 65 / 35 / 20
```

> The brief headlines "100 pts total efficacy score." Because the factor weights sum to 120, v1 treats the score as a **percentage of the 120-point maximum**. This keeps every factor weight exactly as specified in the brief and yields a clean 0–100% scale. (Alternative: rescale weights to sum to 100. Recommend percentage-of-120 to preserve the brief's stated weights — flagged in §13 for sign-off.)

### 8.3 Design constraint (test case + a flagged tension)
> *A treated, opaque stone with perfect wearing compliance should still score below 30%.*

**Intent (satisfied):** wearing behaviour alone cannot rescue a bad stone. Compliance maxes at 20/120 = **17%**, so perfect wearing on a zero-quality, zero-light stone can never reach 30%. The *typical* treated + opaque stone (synthetic/local origin, < 2ct, dull luster, uncertified) scores ≈ **24%** even with perfect compliance — passes.

**Tension to resolve (see §13):** carat, luster, and certification are *independent* of treatment and transparency. A stone can be treated and opaque yet large, surface-lustrous, and lab-certified. Under the brief's fixed weights, such a stone reaches ≈ **46–51%**, i.e. *above* 30%. So the brief's statement is **not** literally true for every treated+opaque stone — only the common one. Product/astrology must choose one of:
- **(a)** Accept the weights as-is — the constraint is a typical-case illustration, not a hard rule (recommended; preserves the brief's exact weights).
- **(b)** Add a **hard gate**: if light transmission = opaque **or** treatment = fracture-filled, cap the overall score at 29% regardless of other factors.

The engine and acceptance test (§12) follow whichever is signed off.

### 8.4 Verdict bands (result screen copy, from the brief)

| Score | Verdict | Message |
|---|---|---|
| 80–100% | **Highly effective** | "Your stone meets most of the key Vedic criteria. It is likely working as intended." |
| 55–79% | **Partially effective** | "Your stone has some strong factors, but specific gaps are reducing its astrological impact." |
| 30–54% | **Weakly effective** | "Several critical factors are missing. This stone is unlikely to be delivering meaningful planetary benefit." |
| 0–29% | **Not effective** | "This stone does not meet the core criteria for Vedic gemstone efficacy. Wearing it is unlikely to have any astrological effect." |

---

## 9. Result screen

**Must show:**
1. **Overall efficacy %** as a large serif number inside a champagne-gold progress ring, with the verdict label and message beneath.
2. **Three mini pillar bars** — Stone Quality, Light & Luster, Wearing Compliance — each as its own percentage, so the customer sees *which pillar* is dragging the score. (A stone scoring 80% on quality but 20% on light needs a very different conversation than the reverse.)
3. **Gap breakdown** — for each factor where the customer lost meaningful points, a one-line, plain-language explanation of the gap and why it matters (e.g. "Your stone is opaque — light can't pass through, which Jyotish treats as a complete blockage."). Phrased as clarity, never shame.
4. **Hand-off CTA** — context-aware next step toward AstroLaabh: e.g. book a consultation, get the stone certified, or have it energised. The weakest pillar should drive which CTA is emphasized (energising service for compliance gaps, certification for verifiability gaps, consultation/upgrade for quality gaps).
5. **Lead capture** (post-result, optional): name + phone/email + WhatsApp opt-in to receive the full breakdown and talk to an expert.
6. **Share / save** result (optional v1.1).

---

## 10. Light engineering specification

### 10.1 Recommended stack
- **Frontend:** React (Next.js) + TypeScript, mobile-first responsive. Tailwind (or CSS variables) wired to the brand tokens in §5.1.
- **State:** local component/store state for the in-progress quiz (no backend round-trips per step). The whole questionnaire config and scoring are client-side; the only server calls are lead submission and analytics.
- **Hosting:** static/SSR via the existing AstroLaabh web stack; CDN for the (large) reference imagery — lazy-load per step, served as optimized WebP/AVIF with width-appropriate variants.
- **Persistence:** answers held in memory + optional `sessionStorage` so a refresh mid-flow doesn't lose progress. Lead + result row written to backend/CRM on submit.

### 10.2 Data model

```ts
type StoneId = 'yellow_sapphire' | 'blue_sapphire' | 'ruby' | 'emerald';

interface StoneMeta {
  id: StoneId;
  displayName: string;        // "Yellow Sapphire"
  vedicName: string;          // "Pukhraj"
  planet: string;             // "Jupiter"
  correctMetals: string[];    // ["gold"]  | ["silver","panchdhatu"]
  correctFinger: 'index' | 'middle' | 'ring' | 'little';
}

interface Option {
  id: string;
  label: string;
  subLabel?: string;
  points: number;             // raw points awarded for this factor
}

interface Question {
  step: number;               // 1..9
  factorKey: FactorKey | null;// null for Step 1 (anchor, 0 pts)
  pillar: 'quality' | 'light' | 'compliance' | null;
  maxPoints: number;
  title: string;
  hint?: string;
  options: Option[] | DynamicOptions; // Step 8 is dynamic on StoneId
  image: ImageSpec;
}

type FactorKey =
  | 'origin' | 'treatment' | 'carat' | 'certification'
  | 'light_transmission' | 'luster'
  | 'metal' | 'finger' | 'energising';

interface Answers { [step: number]: { optionId: string; points: number } }
```

### 10.3 Scoring engine (pure function)

```ts
const PILLAR_MAX = { quality: 65, light: 35, compliance: 20 };
const TOTAL_MAX  = 120;

function score(answers: Answers, questions: Question[]) {
  const pillarRaw = { quality: 0, light: 0, compliance: 0 };
  for (const q of questions) {
    if (!q.pillar) continue;
    pillarRaw[q.pillar] += answers[q.step]?.points ?? 0;
  }
  const rawTotal = pillarRaw.quality + pillarRaw.light + pillarRaw.compliance;
  const efficacyPercent = Math.round((rawTotal / TOTAL_MAX) * 100);
  const pillarPercent = {
    quality:    Math.round(pillarRaw.quality   / PILLAR_MAX.quality   * 100),
    light:      Math.round(pillarRaw.light     / PILLAR_MAX.light     * 100),
    compliance: Math.round(pillarRaw.compliance/ PILLAR_MAX.compliance* 100),
  };
  return { efficacyPercent, pillarPercent, pillarRaw, verdict: verdictFor(efficacyPercent) };
}
```

### 10.4 Dynamic logic (Step 8)
On reaching Step 8, read `StoneMeta` for the Step 1 selection and render:
- **Metal options:** a fixed list (Gold / Silver / Panchdhatu / Don't know / Other). Award full 8 pts if the chosen metal ∈ `correctMetals`; recommend partial (e.g. 3 pts) for "Don't know"; 0 otherwise.
- **Finger options:** Index / Middle / Ring / Little / Don't know. Award full 5 pts if chosen === `correctFinger`; 0 otherwise.
- Result copy references the planet/stone (e.g. "Jupiter's stone should be set in gold").

### 10.5 Content & config
All questions, options, points, hint text, verdict copy, and image references live in a single typed config object (or CMS-backed JSON) so astrology/product can tune wording and point values **without code changes**. Engineering reads from this config; nothing is hard-coded in components.

### 10.6 Analytics events
`quiz_start`, `step_view` (step, stoneId), `step_answer` (step, optionId, points), `quiz_complete` (efficacyPercent, pillarPercent), `verdict_view`, `lead_submit`, `cta_click` (which service), `drop_off` (last step seen).

### 10.7 Accessibility & quality
- WCAG AA contrast — verify gold-on-cream and olive combinations meet 4.5:1 for text.
- Full keyboard navigation; options as proper radio groups with labels; visible focus states.
- All reference images require descriptive `alt` text (they carry meaning, not decoration).
- Reduced-motion support for the progress ring / transitions.
- Performance budget: images lazy-loaded and compressed; LCP under 2.5s on mid-tier mobile/4G.

---

## 11. Content & copy requirements
- Question titles, hints, sub-labels, and verdict messages: use the exact brief wording where given (§7, §8.4).
- Gap-breakdown lines (result screen) need to be authored per factor × low-score combination — a content task owned by product/astrology, kept in the config (§10.5).
- Tone QA pass against design principle #1 ("knowledgeable friend, not a form") before launch.

---

## 12. Acceptance criteria
1. All 9 steps render mobile-first with correct question, options, sub-labels, hint, and prescribed image slot.
2. Step 1 selection correctly drives Step 8 dynamic options and the correct-answer logic for all four stones.
3. Scoring engine matches the point tables in §7/§8 exactly; pillar maxes are 65 / 35 / 20; overall is a 0–100% of 120.
4. **Constraint test:** a *typical* treated + opaque stone (low carat, dull, uncertified) with perfect compliance scores **< 30%**; and compliance-only (zero quality/light) never reaches 30%. If decision §13.8(b) is taken, any opaque or fracture-filled stone is hard-capped at 29%.
5. Verdict bands map exactly to §8.4 thresholds, including boundary values (30, 55, 80).
6. Result screen shows overall ring + three pillar bars + per-factor gap breakdown + context-aware CTA.
7. Back/forward navigation preserves answers; refresh mid-flow does not lose progress.
8. No login required to complete and view result; lead capture is post-result and optional.
9. WCAG AA contrast and keyboard nav verified; all images have alt text.
10. Analytics events fire as specified in §10.6.

---

## 13. Open questions / decisions for sign-off
1. **Normalization:** confirm percentage-of-120 (recommended, preserves brief weights) vs rescaling weights to sum to 100.
2. **Intermediate option points** (§7): astrology/product to approve the interpolated values for non-max, non-zero options.
3. **"Don't know" partial credit** for metal (Step 8) and energising (Step 9): confirm exact values.
4. **Lead-capture requirement:** is contact capture optional (recommended) or required to reveal the full breakdown?
5. **Hand-off destination:** which exact AstroLaabh services/pages do the result CTAs point to, and what's the WhatsApp/CRM integration?
6. **Stone set:** v1 covers the four stones in the brief — confirm no additional stones (e.g., pearl, coral, hessonite) are in scope for v1.
7. **Imagery readiness:** the Step 4 / Step 5 4-panels are blocking for launch — confirm photo production timeline.
8. **Worst-case score cap (§8.3):** accept the brief's weights as-is (treated+opaque "< 30%" is a typical-case illustration), **or** add a hard gate capping any opaque / fracture-filled stone at 29%. This is the single most important scoring decision — it changes whether quality truly cannot be compensated by carat/luster/cert.

---

## 14. Phasing (suggested)
- **v1 (launch):** full 9-step flow, scoring, result screen with pillar bars + gap breakdown, optional lead capture, analytics, all prescribed imagery.
- **v1.1:** shareable/saveable result, multilingual (Hindi + regional), additional stones, A/B testing of CTA copy.
- **v2:** authenticated history, integration with consultation booking + energising service checkout, personalized upgrade recommendations.

---

*Source: AstroLaabh — Internal Design Brief — Gemstone Efficacy Meter; AstroLaabh Brand Direction (Final V1).*
